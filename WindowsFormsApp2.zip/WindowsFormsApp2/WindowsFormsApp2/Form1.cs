﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox2.Visible = true;
            label3.Visible = true;
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                float a = float.Parse(textBox1.Text);
                float b = float.Parse(textBox2.Text);

                float result = a + b;
                textBox3.Text = result.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox2.Visible = true;
            label3.Visible = true;
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                float a = float.Parse(textBox1.Text);
                float b = float.Parse(textBox2.Text);

                float result = a - b;
                textBox3.Text = result.ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox2.Visible = true;
            label3.Visible = true;

            if (textBox1.Text != "" && textBox2.Text != "")
            {
                float a = float.Parse(textBox1.Text);
                float b = float.Parse(textBox2.Text);

                float result = a * b;
                textBox3.Text = result.ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox2.Visible = true;
            label3.Visible = true;

            if (textBox1.Text != "" && textBox2.Text != "")
            {
                float a = float.Parse(textBox1.Text);
                float b = float.Parse(textBox2.Text);

                if (b == 0)
                {
                    textBox3.Text = "Nie dzielimy przez 0";
                }
                else
                {
                    float result = a / b;
                    textBox3.Text = result.ToString();
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox2.Visible = true;
            label3.Visible = true;
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                float a = float.Parse(textBox1.Text);
                float b = float.Parse(textBox2.Text);

                if (Math.Floor(a) == a && Math.Floor(b) == b && a > 0 && b > 0)
                {
                    while (a != b)
                    {
                        if (a > b)
                        {
                            a = a - b;
                        }
                        else
                        {
                            b = b - a;
                        }
                    }
                    textBox3.Text = a.ToString();
                }
                else
                {
                    textBox3.Text = "Nieprawidłowe liczby";
                }
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox2.Visible = true;
            label3.Visible = true;

            if (textBox1.Text != "" && textBox2.Text != "")
            {
                float a = float.Parse(textBox1.Text);
                int b = int.Parse(textBox2.Text);

                float result = 1;

                if (b >= 0)
                {
                    for (int i = 0; i < b; i++)
                    {
                        result *= a;
                    }
                    textBox3.Text = result.ToString();
                }
                else
                {
                    textBox3.Text = "Wykładnik jest nieprawidłowy";
                }
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox2.Visible = false;
            label3.Visible = false;
            if (textBox1.Text != "" && textBox2.Text != "")
            {

                float a = float.Parse(textBox1.Text);
                float r = 0;

                float sumaCyfr = 0;
                if (a >= 0)
                {
                    while (a != 0)
                    {
                        r = a % 10;
                        sumaCyfr += r;
                        a = (a - r) / 10;
                    }
                    textBox3.Text = sumaCyfr.ToString();
                }
                else
                {
                    textBox3.Text = "Nieprawidłowa liczba";
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            float a = float.Parse(textBox1.Text);

            int n = (int)Math.Floor(a);

            textBox2.Visible = false;
            label3.Visible = false;

            if (n < 0)
            {
                textBox3.Text = "Silnia nie jest dla ujemnych cyfr.";
            }
            else
            {
                long silnia = 1;
                for (int i = 1; i <= n; i++)
                {
                    silnia *= i;
                }
                textBox3.Text = silnia.ToString();
            }
        }
    }
}